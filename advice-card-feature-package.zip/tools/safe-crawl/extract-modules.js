import fs from "node:fs/promises";
import path from "node:path";

const config = JSON.parse(await fs.readFile("tools/safe-crawl/config.json", "utf8"));
const rawPath = path.resolve(config.outputRaw);
const detailPath = path.resolve(config.outputDetails);
const outPath = path.resolve(config.outputModules);

const PLACE_HINTS = [
  "西湖",
  "灵隐寺",
  "断桥",
  "浙江省博物馆",
  "湖滨",
  "河坊街",
  "南宋御街",
  "法喜寺",
  "小河直街",
  "龙井村"
];

function isNavigationNoise(text) {
  const navWords = ["周边游", "水上娱乐", "展馆展览", "动植物园", "温泉", "滑雪", "酒店", "五星", "经济连锁", "生活服务", "家政", "文印图文", "搬家运输"];
  const hits = navWords.filter((word) => text.includes(word)).length;
  const hasListingSignal = /条评价|人均|￥|优惠|分店/.test(text);
  const looksLikeCategoryCloud = !hasListingSignal && text.length > 60 && /(更多|菜系|热门推荐|周边玩乐|周边设施)/.test(text);
  return (hits >= 3 && !hasListingSignal) || looksLikeCategoryCloud;
}

function isPlatformChromeNoise(row) {
  const text = row.text || "";
  if (/沪ICP备|营业执照|增值电信业务经营许可证|互联网药品信息服务|违法不良信息举报/.test(text)) return true;
  if (/问点点\s*ai\s*推荐\s*穿搭\s*美食\s*彩妆\s*影视\s*职场\s*情感\s*家居\s*游戏\s*旅行\s*健身\s*视频/.test(text)) return true;
  if (/推荐\s*穿搭\s*美食\s*彩妆\s*影视\s*职场\s*情感\s*家居\s*游戏\s*旅行\s*健身\s*视频/.test(text)) return true;

  if (row.platform === "xiaohongshu") {
    const keywordParts = String(row.keyword || "")
      .split(/\s+/)
      .filter((part) => part.length >= 2);
    const hasKeywordSignal = keywordParts.some((part) => text.includes(part));
    const hasHangzhouSignal = /杭州|西湖|灵隐|法喜|河坊|宋城|九溪|云栖|龙井|湖滨|寺|景区|餐厅|民宿|酒店/.test(text);
    const hasTravelSignal = /避坑|避雷|排队|人多|推荐|攻略|周末游|路线|门票|交通|预约|打车|地铁|住宿|美食|餐厅/.test(text);
    if (!hasKeywordSignal && !(hasHangzhouSignal && hasTravelSignal)) return true;
  }

  return false;
}

function parseDianpingListing(text) {
  const match = text.match(/^(.*?)\s+(\d+)\s*条评价\s*\|\s*人均\s*(￥?\d+|[-—])(?:\/人)?\s*(.*?)\s*\|\s*(.*?)(?:\s+优惠[:：].*)?$/);
  if (!match) return null;
  return {
    name: match[1].trim(),
    reviewCount: Number(match[2]),
    avgPrice: match[3].trim(),
    category: match[4].trim(),
    area: match[5].trim()
  };
}

function classify(text) {
  const listing = parseDianpingListing(text);
  if (listing) {
    if (/酒店|民宿|住宿|客栈|旅社/.test(listing.category)) return "住宿";
    if (/菜|料理|餐|火锅|咖啡|面|小吃|甜点|牛排|自助|烧烤/.test(listing.category)) return "餐饮";
    if (/景观|景点|游乐|乐园|体验|密室|剧|旅拍|服饰|新奇/.test(listing.category)) return "景点";
  }
  if (/酒店|民宿|住宿|入住|房间/.test(text)) return "住宿";
  if (/餐厅|饭店|咖啡|面馆|小吃|人均|好吃|难吃|排队/.test(text)) return "餐饮";
  if (/地铁|公交|打车|步行|交通|停车|堵车/.test(text)) return "交通";
  if (/避坑|避雷|人多|排队|闭店|限流|贵|踩雷|不好/.test(text)) return "避坑";
  return "景点";
}

function findPlace(text, fallbackCity) {
  const listing = parseDianpingListing(text);
  if (listing) return listing.name;
  const found = PLACE_HINTS.find((name) => text.includes(name));
  if (found) return found;
  const match = text.match(/([一-龥A-Za-z0-9]{2,12})(?:景区|餐厅|饭店|咖啡|酒店|博物馆|寺|街|湖|山|公园)/);
  return match?.[0] || fallbackCity;
}

function pickSentences(text, pattern) {
  return text
    .split(/[。！？!?；;\n]/)
    .map((item) => item.trim())
    .filter((item) => item.length > 3 && pattern.test(item))
    .slice(0, 4);
}

function confidenceFrom(text, source) {
  let score = 0;
  if (/人均|¥|元|\d+/.test(text)) score += 1;
  if (/建议|不建议|避开|适合|排队|人多/.test(text)) score += 1;
  if (source?.platform) score += 1;
  return score >= 3 ? "high" : score === 2 ? "medium" : "low";
}

const raw = await fs.readFile(rawPath, "utf8").catch(() => "");
const detailRaw = await fs.readFile(detailPath, "utf8").catch(() => "");
const rows = `${raw}\n${detailRaw}`
  .split("\n")
  .filter(Boolean)
  .map((line) => JSON.parse(line))
  .filter((row) => row.text && !row.error)
  .filter((row) => !isPlatformChromeNoise(row))
  .filter((row) => !/\/member\//.test(row.url || ""))
  .filter((row) => {
    if (parseDianpingListing(row.text)) return true;
    if (isNavigationNoise(row.text)) return false;
    return /避坑|避雷|人多|排队|闭店|限流|贵|踩雷|不好|不建议|推荐|值得|适合/.test(row.text);
  });

const seenModuleKeys = new Set();
const uniqueRows = rows.filter((row) => {
  const listing = parseDianpingListing(row.text);
  const placeName = listing?.name || row.heading || findPlace(row.text, row.city);
  const key = `${row.platform}:${row.keyword}:${placeName}:${row.text.slice(0, 120)}`;
  if (seenModuleKeys.has(key)) return false;
  seenModuleKeys.add(key);
  return true;
});

const modules = uniqueRows.map((row, index) => {
  const text = row.text;
  const listing = parseDianpingListing(text);
  const sourceListing = row.listingText ? parseDianpingListing(row.listingText) : null;
  const avoidReasons = pickSentences(text, /避坑|避雷|人多|排队|闭店|限流|贵|踩雷|不好|不建议|别去/);
  const recommendReasons = pickSentences(text, /推荐|值得|好吃|好看|适合|方便|免费|舒服|出片|不错/);
  const budgetInfo = pickSentences(text, /人均|¥|元|门票|价格|预算/).join("；");
  const trafficInfo = pickSentences(text, /地铁|公交|打车|步行|交通|停车/).join("；");
  const keywordAvoidReasons = /排队|避坑|避雷/.test(row.keyword)
    ? [`搜索关键词包含“${row.keyword}”，说明用户正在关注该地点或品类的避坑风险，需进一步查看评论详情验证。`]
    : [];
  const listingRecommendReasons = listing
    ? [`${listing.reviewCount} 条评价`, `人均 ${listing.avgPrice}`, `${listing.category}`, `${listing.area}`].filter(Boolean)
    : [];

  return {
    id: `module_${String(index + 1).padStart(4, "0")}`,
    city: row.city,
    placeName: sourceListing?.name || listing?.name || row.heading || findPlace(text, row.city),
    type: sourceListing ? classify(row.listingText) : classify(text),
    title: `${sourceListing?.name || listing?.name || row.heading || findPlace(text, row.city)}${avoidReasons.length || keywordAvoidReasons.length ? "避坑线索" : "推荐线索"}`,
    recommendReasons: [...listingRecommendReasons, ...recommendReasons],
    avoidReasons: [...avoidReasons, ...keywordAvoidReasons],
    budgetInfo: sourceListing ? `人均 ${sourceListing.avgPrice}` : listing ? `人均 ${listing.avgPrice}` : budgetInfo,
    trafficInfo,
    category: sourceListing?.category || listing?.category || "",
    area: sourceListing?.area || listing?.area || "",
    reviewCount: sourceListing?.reviewCount || listing?.reviewCount || null,
    evidence: text.slice(0, 280),
    source: {
      platform: row.platform,
      keyword: row.keyword,
      url: row.url,
      capturedAt: row.capturedAt,
      sourceType: row.kind === "detail_review" ? "detail_review" : listing ? "search_result_listing" : "page_text"
    },
    confidence: row.kind === "detail_review" ? "high" : listing ? "medium" : confidenceFrom(text, row)
  };
});

await fs.mkdir(path.dirname(outPath), { recursive: true });
await fs.writeFile(outPath, JSON.stringify(modules, null, 2), "utf8");
console.log(`[extract] wrote ${modules.length} modules to ${config.outputModules}`);
