# Safe Travel Data Pipeline

这个目录用于黑客松 Demo 的“旅游避坑/推荐知识库”。

## 安全边界

- 只读取公开可访问页面。
- 不绕过验证码、不破解登录、不模拟异常高频访问。
- 不采集头像、昵称、手机号等个人隐私。
- 不批量保存图片、视频、完整评论区个人信息。
- 抓取失败时保留错误记录，后续可使用样例数据或用户粘贴内容继续跑 RAG。

## 使用流程

安装依赖：

```bash
npm install
```

如果需要预登录：

```bash
npm run crawl:login
```

浏览器打开后手动登录平台，完成后关闭脚本即可。脚本不会读取或保存密码，只保存浏览器会话目录。
如果平台提示 IP 风险、验证码或安全限制，请停止该平台采集，不要绕过限制。

采集公开页面文本：

```bash
npm run crawl:safe
```

采集详情页评论片段：

```bash
SAFE_CRAWL_HEADLESS=false npm run crawl:details
```

详情采集只会打开搜索结果中的少量详情链接，低频读取页面可见文本片段。遇到登录、验证码、安全限制时停止该页面，不做绕过。

如果结果是 0 rows，先看诊断文件：

```bash
tail -n 8 data/raw/crawl_debug.jsonl
```

诊断里 `bodyTextLength` 很小，通常表示页面被登录、验证码、空白壳或网络策略拦住；`bodyTextLength` 很大但没有结果，通常表示抽取关键词规则需要调整。

如果在 Codex 沙盒里启动浏览器失败，请在 macOS Terminal 里运行同样命令：

```bash
cd /Users/wuyiqin/Desktop/dy-hackathon
npm run crawl:safe
```

如果无头浏览器仍然失败，可以改用有界面模式：

```bash
SAFE_CRAWL_HEADLESS=false npm run crawl:safe
```

抽取旅行模块：

```bash
npm run crawl:extract
```

构建本地轻量 RAG 索引：

```bash
npm run rag:build
```

查询：

```bash
npm run rag:query -- "杭州 西湖 避坑 人多"
```

## Demo 解释

真实产品可以把这里的轻量索引替换成 Chroma、FAISS、pgvector 或云向量数据库。当前版本重点验证链路：

```text
平台文本/视频文案 -> 结构化避坑模块 -> 本地 RAG 检索 -> agent 生成建议 -> 用户编辑/删除/加入路线
```
