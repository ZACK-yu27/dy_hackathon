import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const authDir = path.resolve("data/auth");
const profileDir = path.join(authDir, "browser-profile");

await fs.mkdir(authDir, { recursive: true });

console.log("Opening a persistent browser profile.");
console.log("Log in manually if a site asks you to. Close the browser when done.");
console.log(`Profile will be stored at: ${profileDir}`);

let context;
try {
  context = await chromium.launchPersistentContext(profileDir, {
    headless: false,
    viewport: { width: 1280, height: 900 },
    chromiumSandbox: false
  });
} catch (error) {
  console.error("Could not start Chromium from this environment.");
  console.error("Please run the same command from your macOS Terminal:");
  console.error("  cd /Users/wuyiqin/Desktop/dy-hackathon && npm run crawl:login");
  console.error(`Original error: ${error.message.split("\n")[0]}`);
  process.exit(1);
}

const xhs = await context.newPage();
await xhs.goto("https://www.xiaohongshu.com", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});

const dianping = await context.newPage();
await dianping.goto("https://www.dianping.com", { waitUntil: "domcontentloaded", timeout: 60000 }).catch(() => {});

console.log("Opened Xiaohongshu and Dianping.");
console.log("If a platform shows login or safety verification, complete only the normal on-screen flow.");
console.log("Do not try to bypass captcha or safety blocks.");
await dianping.bringToFront().catch(() => {});
await xhs.bringToFront().catch(() => {});
await xhs.waitForTimeout(3000);

process.on("SIGINT", async () => {
  await context.close();
  process.exit(0);
});

await new Promise(() => {});
