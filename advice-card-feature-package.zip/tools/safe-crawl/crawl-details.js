import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const config = JSON.parse(await fs.readFile("tools/safe-crawl/config.json", "utf8"));
const authProfileDir = path.resolve("data/auth/browser-profile");
const outPath = path.resolve(config.outputDetails);
const debugPath = path.resolve(config.outputDebug);

await fs.mkdir(path.dirname(outPath), { recursive: true });

function fillTemplate(template, keyword) {
  return template.replace("{keyword}", encodeURIComponent(keyword));
}

function cleanText(text) {
  return text
    .replace(/\s+/g, " ")
    .replace(/[\u0000-\u001f]/g, "")
    .trim();
}

function normalizeUrl(href, platformName) {
  if (!href) return "";
  try {
    const base = platformName === "xiaohongshu" ? "https://www.xiaohongshu.com" : "https://www.dianping.com";
    const url = new URL(href, base);
    if (platformName === "xiaohongshu") {
      if (!/^\/explore\//.test(url.pathname)) return "";
      url.hash = "";
      return url.toString();
    }
    if (!/^\/shop\//.test(url.pathname)) return "";
    return url.toString();
  } catch {
    return "";
  }
}

function isUsefulReviewText(text) {
  if (text.length < 20 || text.length > 1200) return false;
  return /排队|人多|服务|环境|口味|价格|人均|推荐|踩雷|避坑|避雷|不值|难吃|好吃|拥挤|等位|预约|停车|交通|门票|体验|适合|不适合/.test(text);
}

function isSafetyBlocked(text) {
  return /安全限制|IP存在风险|验证|captcha|访问过于频繁|请切换可靠网络/.test(text);
}

async function appendJsonl(filePath, rows) {
  if (!rows.length) return;
  await fs.appendFile(filePath, rows.map((row) => JSON.stringify(row)).join("\n") + "\n", "utf8");
}

async function launchContext() {
  const headless = process.env.SAFE_CRAWL_HEADLESS !== "false";
  try {
    return await chromium.launchPersistentContext(authProfileDir, {
      headless,
      viewport: { width: 1280, height: 900 },
      chromiumSandbox: false
    });
  } catch (error) {
    console.error("Could not start Chromium from this environment.");
    console.error("Please run from macOS Terminal:");
    console.error("  cd /Users/wuyiqin/Desktop/dy-hackathon && SAFE_CRAWL_HEADLESS=false npm run crawl:details");
    console.error(`Original error: ${error.message.split("\n")[0]}`);
    process.exit(1);
  }
}

async function collectDetailLinks(page, platformName) {
  const links = await page.locator("body").evaluate((body) => {
    const result = [];
    for (const anchor of body.querySelectorAll("a[href]")) {
      const href = anchor.getAttribute("href") || "";
      const parentText = anchor.closest("li, div, section, article")?.innerText || anchor.innerText || "";
      if (/xiaohongshu\.com|\/explore\//.test(href)) {
        if (parentText.length > 6) result.push({ href, text: parentText });
        continue;
      }
      if (/\/shop\//.test(href)) {
        if (!/条评价|人均|￥|景点|餐厅|美食|酒店|乐园|自然景观|旅拍|密室/.test(parentText)) continue;
        if (/\/member\/|\/reviews/.test(href)) continue;
        result.push({ href, text: parentText });
      }
    }
    return result;
  }).catch(() => []);

  const seen = new Set();
  return links
    .map((item) => ({ url: normalizeUrl(item.href, platformName), listingText: cleanText(item.text).slice(0, 500) }))
    .filter((item) => item.url)
    .filter((item) => {
      if (seen.has(item.url)) return false;
      seen.add(item.url);
      return true;
    })
    .slice(0, config.maxDetailItemsPerKeyword);
}

async function extractDetail(page) {
  return page.locator("body").evaluate((body) => {
    const title = document.title || "";
    const bodyText = body.innerText || "";
    const heading = [...body.querySelectorAll("h1,h2,[class*=title],[class*=name]")]
      .map((el) => el.innerText || "")
      .find((text) => text.trim().length > 1) || "";

    const candidates = [];
    const selectors = [
      "[class*=review]",
      "[class*=comment]",
      "[class*=remark]",
      "[class*=content]",
      "[class*=txt]",
      "p",
      "li"
    ];
    for (const selector of selectors) {
      for (const el of body.querySelectorAll(selector)) {
        const text = el.innerText || "";
        if (text.length > 15 && text.length < 1500) candidates.push(text);
      }
    }

    const bodyLines = bodyText
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 15 && line.length < 900);

    return { title, heading, bodyText, candidates: [...candidates, ...bodyLines] };
  }).catch(() => ({ title: "", heading: "", candidates: [] }));
}

const context = await launchContext();
await context.route("**/*", async (route) => {
  const type = route.request().resourceType();
  if (config.blockedResourceTypes.includes(type)) {
    await route.abort();
  } else {
    await route.continue();
  }
});

const page = await context.newPage();
const platforms = config.platforms.filter((item) => item.enabled && ["dianping", "xiaohongshu"].includes(item.name));
const rows = [];
const debugRows = [];

for (const platform of platforms) {
  for (const keyword of config.keywords) {
    const searchUrl = fillTemplate(platform.searchUrlTemplate, keyword);
    console.log(`[detail-crawl] search ${platform.name} keyword="${keyword}"`);
    try {
      await page.goto(searchUrl, { waitUntil: "domcontentloaded", timeout: 45000 });
      await page.waitForTimeout(config.delayMs);
      const searchBody = cleanText(await page.locator("body").innerText().catch(() => ""));
      if (isSafetyBlocked(searchBody)) {
        debugRows.push({
          kind: "detail_search_safety_blocked",
          platform: platform.name,
          keyword,
          url: page.url(),
          title: await page.title().catch(() => ""),
          bodyTextPreview: searchBody.slice(0, 700),
          capturedAt: new Date().toISOString()
        });
        console.log(`[detail-crawl] ${platform.name} safety blocked, skip remaining keywords`);
        break;
      }
      await page.mouse.wheel(0, 1200).catch(() => {});
      await page.waitForTimeout(config.delayMs);

      const links = await collectDetailLinks(page, platform.name);
      console.log(`[detail-crawl] found ${links.length} detail links`);
      if (!links.length) {
        const text = await page.locator("body").innerText().catch(() => "");
        debugRows.push({
          kind: "detail_link_empty",
          platform: platform.name,
          keyword,
          url: page.url(),
          title: await page.title().catch(() => ""),
          bodyTextPreview: cleanText(text).slice(0, 700),
          capturedAt: new Date().toISOString()
        });
      }

      for (const link of links) {
        console.log(`[detail-crawl] open ${link.url}`);
        await page.goto(link.url, { waitUntil: "domcontentloaded", timeout: 45000 });
        await page.waitForTimeout(config.delayMs);
        await page.mouse.wheel(0, 1600).catch(() => {});
        await page.waitForTimeout(config.delayMs);
        const detail = await extractDetail(page);
        const detailBody = cleanText(detail.bodyText || "");
        if (isSafetyBlocked(detailBody)) {
          debugRows.push({
            kind: "detail_page_safety_blocked",
            platform: platform.name,
            keyword,
            url: page.url(),
            title: detail.title,
            bodyTextPreview: detailBody.slice(0, 700),
            capturedAt: new Date().toISOString()
          });
          continue;
        }
        const seen = new Set();
        const snippets = detail.candidates
          .map(cleanText)
          .filter(isUsefulReviewText)
          .filter((text) => {
            const key = text.slice(0, 120);
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
          })
          .slice(0, config.maxReviewSnippetsPerDetail);

        if (!snippets.length) {
          debugRows.push({
            kind: "detail_snippet_empty",
            platform: platform.name,
            keyword,
            url: page.url(),
            title: detail.title,
            heading: cleanText(detail.heading),
            listingText: link.listingText,
            bodyTextPreview: detailBody.slice(0, 700),
            capturedAt: new Date().toISOString()
          });
        }

        rows.push(...snippets.map((text) => ({
          kind: "detail_review",
          platform: platform.name,
          keyword,
          city: config.city,
          url: page.url(),
          pageTitle: detail.title,
          heading: cleanText(detail.heading),
          listingText: link.listingText,
          text,
          capturedAt: new Date().toISOString()
        })));
        await page.waitForTimeout(config.delayMs);
      }
    } catch (error) {
      debugRows.push({
        kind: "detail_error",
        platform: platform.name,
        keyword,
        url: searchUrl,
        error: error.message.split("\n")[0],
        capturedAt: new Date().toISOString()
      });
    }
  }
}

await appendJsonl(outPath, rows);
await appendJsonl(debugPath, debugRows);
await context.close();

console.log(`[detail-crawl] wrote ${rows.length} review rows to ${config.outputDetails}`);
if (debugRows.length) console.log(`[detail-crawl] wrote ${debugRows.length} debug rows to ${config.outputDebug}`);
