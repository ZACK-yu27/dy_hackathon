import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";

const configPath = path.resolve("tools/safe-crawl/config.json");
const config = JSON.parse(await fs.readFile(configPath, "utf8"));
const authProfileDir = path.resolve("data/auth/browser-profile");
const outPath = path.resolve(config.outputRaw);
const debugPath = path.resolve(config.outputDebug);

await fs.mkdir(path.dirname(outPath), { recursive: true });

function fillTemplate(template, keyword) {
  return template.replace("{keyword}", encodeURIComponent(keyword));
}

function cleanText(text) {
  return text
    .replace(/\s+/g, " ")
    .replace(/[\u0000-\u001f]/g, "")
    .trim();
}

function looksUseful(text) {
  if (text.length < 30) return false;
  return /避坑|避雷|推荐|排队|人多|价格|人均|好吃|难吃|交通|打车|地铁|景点|餐厅|住宿|酒店|闭店|限流|门票/.test(text);
}

async function readBodyText(page) {
  return page.locator("body").innerText().catch(() => "");
}

function isSafetyBlocked(text) {
  return /安全限制|IP存在风险|验证|captcha|访问过于频繁|请切换可靠网络/.test(text);
}

async function extractTexts(page) {
  const payload = await page.locator("body").evaluate((body) => {
    const candidates = [];
    const bodyText = body.innerText || "";
    const selectors = [
      "article",
      "a",
      "p",
      "span",
      "li",
      "[class*=note]",
      "[class*=feed]",
      "[class*=review]",
      "[class*=comment]",
      "[class*=content]",
      "main",
      "section",
      "div"
    ];
    for (const selector of selectors) {
      for (const el of body.querySelectorAll(selector)) {
        const text = el.innerText || "";
        if (text.length > 20 && text.length < 4000) candidates.push(text);
      }
    }
    return { bodyText, candidates };
  }).catch(() => ({ bodyText: "", candidates: [] }));

  const lineChunks = payload.bodyText
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 20 && line.length < 800);

  const seen = new Set();
  return [...payload.candidates, ...lineChunks]
    .map(cleanText)
    .filter(looksUseful)
    .filter((text) => {
      const key = text.slice(0, 120);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 12);
}

async function getDiagnostics(page, platform, keyword, error = null) {
  const info = await page.locator("body").evaluate((body) => {
    const text = (body.innerText || "").replace(/\s+/g, " ").trim();
    return {
      bodyTextLength: text.length,
      bodyTextPreview: text.slice(0, 700)
    };
  }).catch(() => ({ bodyTextLength: 0, bodyTextPreview: "" }));

  return {
    platform,
    keyword,
    city: config.city,
    url: page.url(),
    title: await page.title().catch(() => ""),
    bodyTextLength: info.bodyTextLength,
    bodyTextPreview: info.bodyTextPreview,
    error: error?.message?.split("\n")[0] || null,
    capturedAt: new Date().toISOString()
  };
}

async function appendJsonl(filePath, rows) {
  if (!rows.length) return;
  const payload = rows.map((row) => JSON.stringify(row)).join("\n") + "\n";
  await fs.appendFile(filePath, payload, "utf8");
}

const headless = process.env.SAFE_CRAWL_HEADLESS !== "false";
let context;
try {
  context = await chromium.launchPersistentContext(authProfileDir, {
    headless,
    viewport: { width: 1280, height: 900 },
    chromiumSandbox: false
  });
} catch (error) {
  console.error("Could not start Chromium from this environment.");
  console.error("Please run the same command from your macOS Terminal:");
  console.error("  cd /Users/wuyiqin/Desktop/dy-hackathon && npm run crawl:safe");
  console.error("If it still fails, try a visible browser:");
  console.error("  cd /Users/wuyiqin/Desktop/dy-hackathon && SAFE_CRAWL_HEADLESS=false npm run crawl:safe");
  console.error(`Original error: ${error.message.split("\n")[0]}`);
  process.exit(1);
}

await context.route("**/*", async (route) => {
  const type = route.request().resourceType();
  if (config.blockedResourceTypes.includes(type)) {
    await route.abort();
  } else {
    await route.continue();
  }
});

const page = await context.newPage();
const rows = [];
const debugRows = [];
const globalSeen = new Set();

for (const platform of config.platforms.filter((item) => item.enabled)) {
  let platformBlocked = false;
  for (const keyword of config.keywords) {
    if (platformBlocked) break;
    const url = fillTemplate(platform.searchUrlTemplate, keyword);
    console.log(`[safe-crawl] ${platform.name} keyword="${keyword}"`);
    try {
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: 45000 });
      const firstBodyText = cleanText(await readBodyText(page));
      if (isSafetyBlocked(firstBodyText)) {
        debugRows.push({
          platform: platform.name,
          keyword,
          city: config.city,
          url: page.url(),
          title: await page.title().catch(() => ""),
          bodyTextLength: firstBodyText.length,
          bodyTextPreview: firstBodyText.slice(0, 700),
          error: "safety_blocked",
          capturedAt: new Date().toISOString()
        });
        console.log(`[safe-crawl] ${platform.name} safety blocked, skip remaining keywords`);
        platformBlocked = true;
        break;
      }
      for (let index = 0; index < config.maxPagesPerKeyword; index += 1) {
        await page.waitForTimeout(config.delayMs);
        await page.mouse.wheel(0, 900).catch(() => {});
        const texts = await extractTexts(page);
        const timestamp = new Date().toISOString();
        for (const text of texts) {
          const key = `${platform.name}:${keyword}:${text.slice(0, 160)}`;
          if (globalSeen.has(key)) continue;
          globalSeen.add(key);
          rows.push({
            platform: platform.name,
            keyword,
            city: config.city,
            url: page.url(),
            text,
            capturedAt: timestamp
          });
        }
      }
      if (!rows.some((row) => row.platform === platform.name && row.keyword === keyword)) {
        debugRows.push(await getDiagnostics(page, platform.name, keyword));
      }
    } catch (error) {
      rows.push({
        platform: platform.name,
        keyword,
        city: config.city,
        url,
        error: error.message,
        capturedAt: new Date().toISOString()
      });
      debugRows.push(await getDiagnostics(page, platform.name, keyword, error));
    }
    await page.waitForTimeout(config.delayMs);
  }
}

await appendJsonl(outPath, rows);
await appendJsonl(debugPath, debugRows);
await context.close();

console.log(`[safe-crawl] wrote ${rows.length} rows to ${config.outputRaw}`);
if (debugRows.length) {
  console.log(`[safe-crawl] wrote ${debugRows.length} debug rows to ${config.outputDebug}`);
}
