import fs from "node:fs/promises";
import path from "node:path";

const config = JSON.parse(await fs.readFile("tools/safe-crawl/config.json", "utf8"));
const modules = JSON.parse(await fs.readFile(config.outputModules, "utf8").catch(() => "[]"));
const outPath = path.resolve(config.ragIndex);

const STOPWORDS = new Set(["的", "了", "和", "是", "在", "也", "就", "都", "很", "有", "去", "到", "不"]);

function tokenize(text) {
  const zh = [...text.matchAll(/[\u4e00-\u9fa5]{1,2}/g)].map((m) => m[0]);
  const words = text.toLowerCase().match(/[a-z0-9]+/g) || [];
  return [...zh, ...words].filter((token) => !STOPWORDS.has(token));
}

function vectorize(text) {
  const vector = new Map();
  for (const token of tokenize(text)) {
    vector.set(token, (vector.get(token) || 0) + 1);
  }
  return Object.fromEntries(vector);
}

function moduleToText(item) {
  return [
    `城市：${item.city}`,
    `地点：${item.placeName}`,
    `类型：${item.type}`,
    `标题：${item.title}`,
    `推荐理由：${item.recommendReasons.join("；")}`,
    `避坑理由：${item.avoidReasons.join("；")}`,
    `预算：${item.budgetInfo}`,
    `交通：${item.trafficInfo}`,
    `证据：${item.evidence}`,
    `来源：${item.source?.platform || ""} ${item.source?.keyword || ""}`
  ].join("\n");
}

const documents = modules.map((item) => {
  const text = moduleToText(item);
  return {
    id: item.id,
    text,
    metadata: {
      city: item.city,
      placeName: item.placeName,
      type: item.type,
      source: item.source,
      confidence: item.confidence
    },
    vector: vectorize(text)
  };
});

await fs.mkdir(path.dirname(outPath), { recursive: true });
await fs.writeFile(outPath, JSON.stringify({ createdAt: new Date().toISOString(), documents }, null, 2), "utf8");
console.log(`[rag] wrote ${documents.length} documents to ${config.ragIndex}`);
