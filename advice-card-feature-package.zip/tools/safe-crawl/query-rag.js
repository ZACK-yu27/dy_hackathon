import fs from "node:fs/promises";

const config = JSON.parse(await fs.readFile("tools/safe-crawl/config.json", "utf8"));
const query = process.argv.slice(2).join(" ") || "杭州 西湖 避坑";
const index = JSON.parse(await fs.readFile(config.ragIndex, "utf8").catch(() => "{\"documents\":[]}"));

const STOPWORDS = new Set(["的", "了", "和", "是", "在", "也", "就", "都", "很", "有", "去", "到", "不"]);

function tokenize(text) {
  const zh = [...text.matchAll(/[\u4e00-\u9fa5]{1,2}/g)].map((m) => m[0]);
  const words = text.toLowerCase().match(/[a-z0-9]+/g) || [];
  return [...zh, ...words].filter((token) => !STOPWORDS.has(token));
}

function vectorize(text) {
  const vector = new Map();
  for (const token of tokenize(text)) {
    vector.set(token, (vector.get(token) || 0) + 1);
  }
  return vector;
}

function cosine(a, b) {
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (const value of a.values()) normA += value * value;
  for (const value of Object.values(b)) normB += value * value;
  for (const [key, value] of a.entries()) {
    dot += value * (b[key] || 0);
  }
  return dot / (Math.sqrt(normA) * Math.sqrt(normB) || 1);
}

const qv = vectorize(query);
const results = index.documents
  .map((doc) => ({ ...doc, score: cosine(qv, doc.vector) }))
  .sort((a, b) => b.score - a.score)
  .slice(0, 5);

console.log(JSON.stringify({
  query,
  results: results.map(({ id, score, metadata, text }) => ({
    id,
    score: Number(score.toFixed(4)),
    metadata,
    text: text.slice(0, 600)
  }))
}, null, 2));
