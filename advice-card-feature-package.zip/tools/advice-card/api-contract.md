# 避坑建议卡接口约定

## 前端调用

`POST /api/advice-card`

请求体：

```json
{
  "name": "灵隐寺",
  "category": "景点"
}
```

可选字段：

```json
{
  "name": "灵隐寺",
  "category": "景点",
  "currentRoute": ["西湖", "灵隐寺", "云栖竹径"],
  "travelDate": "周末",
  "userPreference": "轻松，不想排队"
}
```

## 后端返回

```json
{
  "name": "灵隐寺",
  "summary": "值得去，但建议避开高峰，并提前确认预约、门票和路线。",
  "pitfalls": [
    "节假日和周末人流量大，体验可能下降。"
  ],
  "executionTips": [
    "建议上午早一点出发，提前确认预约和门票规则。"
  ],
  "alternatives": [
    "如果当天人太多，可以改去法喜寺或云栖竹径。"
  ],
  "confirmBeforeGo": [
    "是否限流",
    "是否需要预约",
    "飞来峰门票是否包含"
  ],
  "confidence": "中等偏高",
  "sourceSummary": "来自小红书和大众点评的内容线索",
  "cached": false,
  "evidenceCount": 5
}
```

## 前端展示建议

正文区域展示：

- `summary`
- `pitfalls`
- `executionTips`
- `alternatives`
- `confirmBeforeGo`

浅色小字展示：

- `confidence`
- `sourceSummary`

## 对接原则

前端只需要传 `name` 和 `category`，不需要关心 RAG、Prompt 或 API 调用细节。

后端负责：

1. 用 `name + category` 检索 RAG 证据。
2. 把证据放进 Prompt。
3. 调用 DeepSeek 或其他大模型 API。
4. 返回固定 JSON。
5. 缓存结果，避免重复调用 API。
