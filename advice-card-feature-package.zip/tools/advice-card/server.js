import http from "node:http";
import { generateAdviceCard } from "./advice-card.js";

const port = Number(process.env.ADVICE_CARD_PORT || 8787);
const host = process.env.ADVICE_CARD_HOST || "127.0.0.1";

function sendJson(res, status, payload) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  });
  res.end(JSON.stringify(payload, null, 2));
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    sendJson(res, 200, { ok: true });
    return;
  }

  if (req.method !== "POST" || req.url !== "/api/advice-card") {
    sendJson(res, 404, { error: "Not found" });
    return;
  }

  try {
    const body = await readBody(req);
    const card = await generateAdviceCard(body);
    sendJson(res, 200, card);
  } catch (error) {
    sendJson(res, 500, { error: error.message });
  }
});

server.listen(port, host, () => {
  console.log(`[advice-card] listening on http://${host}:${port}`);
});
