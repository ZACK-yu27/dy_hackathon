# 避坑建议卡后端说明

这个文件夹负责把“点击模块”变成“避坑建议卡”。

## 已包含

- `api-contract.md`：给前端/队友看的接口约定
- `prompt-template.md`：给 AI 的固定提示词模板
- `advice-card.js`：RAG 检索 + AI 生成 + 缓存
- `server.js`：最小 HTTP 接口
- `sample-request.json`：前端请求示例
- `sample-response-lingyin.json`：返回示例
- `.env.example`：环境变量示例，不放真实密钥

## 使用方式

先设置环境变量：

```bash
export DEEPSEEK_API_KEY="你的 DeepSeek API Key"
```

或者新建 `tools/advice-card/.env.local`：

```bash
DEEPSEEK_API_KEY=你的 DeepSeek API Key
AI_BASE_URL=https://api.deepseek.com
AI_MODEL=deepseek-v4-flash
```

生成一次建议卡：

```bash
npm run advice:generate -- 灵隐寺 景点
```

启动接口服务：

```bash
npm run advice:server
```

前端请求：

```bash
curl -X POST http://localhost:8787/api/advice-card \
  -H "Content-Type: application/json" \
  -d '{"name":"灵隐寺","category":"景点"}'
```

## 重要说明

建议卡不是写死的。固定的是前端展示字段，变化的是字段里的内容。

流程是：

```text
点击模块 name/category
-> RAG 检索证据
-> Prompt 组织证据
-> DeepSeek 生成 JSON
-> 缓存到 data/cache/advice_cards.json
-> 返回给前端展示
```

如果没有 API Key，脚本会用 RAG 证据生成一版本地兜底建议，方便 demo 不崩。
