import fs from "node:fs/promises";
import path from "node:path";

const ROOT = path.resolve(".");
const RAG_PATH = path.join(ROOT, "data/rag/travel_rag_index.json");
const CACHE_PATH = path.join(ROOT, "data/cache/advice_cards.json");
const PROMPT_PATH = path.join(ROOT, "tools/advice-card/prompt-template.md");
const LOCAL_ENV_PATH = path.join(ROOT, "tools/advice-card/.env.local");

const STOPWORDS = new Set(["的", "了", "和", "是", "在", "也", "就", "都", "很", "有", "去", "到", "不"]);

function tokenize(text) {
  const zh = [...String(text).matchAll(/[\u4e00-\u9fa5]{1,2}/g)].map((m) => m[0]);
  const words = String(text).toLowerCase().match(/[a-z0-9]+/g) || [];
  return [...zh, ...words].filter((token) => !STOPWORDS.has(token));
}

function vectorize(text) {
  const vector = new Map();
  for (const token of tokenize(text)) {
    vector.set(token, (vector.get(token) || 0) + 1);
  }
  return vector;
}

function cosine(a, b) {
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (const value of a.values()) normA += value * value;
  for (const value of Object.values(b)) normB += value * value;
  for (const [key, value] of a.entries()) {
    dot += value * (b[key] || 0);
  }
  return dot / (Math.sqrt(normA) * Math.sqrt(normB) || 1);
}

function normalizeName(name) {
  return String(name || "")
    .replace(/[·\s（）()【】\[\]<>《》,，。:：!！?？\-_/]/g, "")
    .replace(/景区|景点|自然景观|总店|分店|旗舰店|门店|店$/g, "")
    .trim();
}

function cacheKey(input) {
  return `${normalizeName(input.name)}::${input.category || ""}::${input.travelDate || ""}::${input.userPreference || ""}`;
}

async function readJson(filePath, fallback) {
  try {
    return JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch {
    return fallback;
  }
}

async function writeJson(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, JSON.stringify(value, null, 2), "utf8");
}

async function loadLocalEnv() {
  const text = await fs.readFile(LOCAL_ENV_PATH, "utf8").catch(() => "");
  for (const line of text.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#") || !trimmed.includes("=")) continue;
    const [key, ...valueParts] = trimmed.split("=");
    if (!process.env[key]) {
      process.env[key] = valueParts.join("=").replace(/^["']|["']$/g, "");
    }
  }
}

export async function retrieveEvidence(input, topK = 8) {
  const index = await readJson(RAG_PATH, { documents: [] });
  const query = [
    input.name,
    input.category,
    input.travelDate,
    input.userPreference,
    "避坑 执行提醒 交通 排队 预约 门票 替代方案 需要确认"
  ].filter(Boolean).join(" ");

  const qv = vectorize(query);
  const normalizedInputName = normalizeName(input.name);

  return index.documents
    .map((doc) => {
      const metadataName = doc.metadata?.placeName || "";
      const normalizedDocName = normalizeName(metadataName);
      let boost = 0;
      if (normalizedDocName && normalizedDocName === normalizedInputName) boost += 0.7;
      else if (normalizedDocName && (normalizedDocName.includes(normalizedInputName) || normalizedInputName.includes(normalizedDocName))) boost += 0.35;
      if (input.category && doc.metadata?.type === input.category) boost += 0.15;
      return { ...doc, score: cosine(qv, doc.vector) + boost };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .map((doc) => ({
      id: doc.id,
      score: Number(doc.score.toFixed(4)),
      name: doc.metadata?.placeName || "",
      category: doc.metadata?.type || "",
      confidence: doc.metadata?.confidence || "medium",
      source: {
        platform: doc.metadata?.source?.platform || "",
        keyword: doc.metadata?.source?.keyword || "",
        sourceType: doc.metadata?.source?.sourceType || "",
        url: doc.metadata?.source?.url || ""
      },
      text: doc.text.slice(0, 700)
    }));
}

function buildPrompt(input, evidence) {
  return fs.readFile(PROMPT_PATH, "utf8").then((template) => template
    .replace("{{MODULE_JSON}}", JSON.stringify(input, null, 2))
    .replace("{{EVIDENCE_JSON}}", JSON.stringify(evidence, null, 2)));
}

function extractJson(text) {
  const trimmed = String(text || "").trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    const match = trimmed.match(/\{[\s\S]*\}/);
    if (match) return JSON.parse(match[0]);
    throw new Error("AI response is not valid JSON");
  }
}

async function callModel(prompt) {
  await loadLocalEnv();
  const apiKey = process.env.DEEPSEEK_API_KEY || process.env.AI_API_KEY;
  if (!apiKey) return null;

  const baseUrl = (process.env.AI_BASE_URL || "https://api.deepseek.com").replace(/\/$/, "");
  const model = process.env.AI_MODEL || "deepseek-v4-flash";
  const endpoint = `${baseUrl}/chat/completions`;

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: "你是严谨的旅行避坑建议生成器，只输出 JSON。" },
        { role: "user", content: prompt }
      ],
      temperature: 0.2
    })
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`AI API failed: ${response.status} ${body.slice(0, 300)}`);
  }

  const payload = await response.json();
  return extractJson(payload.choices?.[0]?.message?.content || "");
}

function fallbackAdvice(input, evidence) {
  const evidenceText = evidence.map((item) => item.text).join("\n");
  const hasPeopleRisk = /人多|排队|高峰|国庆|周末|拥挤/.test(evidenceText);
  const hasTrafficRisk = /交通|地铁|公交|打车|停车|返程|渡船|摆渡|怎么去/.test(evidenceText);
  const hasRouteRisk = /路线|入口|门票|预约|景区|飞来峰|徒步|时长/.test(evidenceText);

  return {
    name: input.name,
    summary: `${input.name}可以加入行程，但建议先确认${hasPeopleRisk ? "人流" : "现场"}、${hasTrafficRisk ? "交通" : "路线"}和时间安排。`,
    pitfalls: [
      hasPeopleRisk ? "相关内容提到人多、排队或高峰体验问题，热门时段可能影响游玩质量。" : "当前证据不足以判断明显踩坑点，需要结合当天情况确认。",
      hasRouteRisk ? "路线、入口、门票或游玩顺序可能存在理解成本，临时前往容易低估耗时。" : "如果和其他地点组合，需要避免把行程排得过满。"
    ],
    executionTips: [
      "出发前确认开放时间、预约规则、门票规则和预计游玩时长。",
      hasTrafficRisk ? "提前查好去程和返程交通，尤其关注打车、公交、停车或换乘成本。" : "提前确认从当前位置过去的交通时间。"
    ],
    alternatives: [
      "如果当天人多或时间不够，可以把它换成附近更轻量的景点。",
      "如果同行人体力有限，建议减少同一天的其他步行项目。"
    ],
    confirmBeforeGo: [
      "当天是否开放或限流",
      "是否需要预约",
      "实时交通和排队情况",
      "同行人体力和游玩时长",
      "是否有更顺路的替代点"
    ],
    confidence: evidence.length >= 5 ? "中等" : "低",
    sourceSummary: `基于 ${evidence.length} 条 RAG 证据线索生成，未调用 AI API。`
  };
}

export async function generateAdviceCard(input, options = {}) {
  if (!input?.name) throw new Error("name is required");

  const cache = await readJson(CACHE_PATH, {});
  const key = cacheKey(input);
  if (!options.refresh && cache[key]) {
    return { ...cache[key], cached: true };
  }

  const evidence = await retrieveEvidence(input, options.topK || 8);
  const prompt = await buildPrompt(input, evidence);
  const aiCard = await callModel(prompt);
  const card = aiCard || fallbackAdvice(input, evidence);

  const result = {
    ...card,
    cached: false,
    evidenceCount: evidence.length,
    evidence: options.includeEvidence ? evidence : undefined
  };

  cache[key] = {
    ...card,
    evidenceCount: evidence.length,
    generatedAt: new Date().toISOString()
  };
  await writeJson(CACHE_PATH, cache);

  return result;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const [name, category] = process.argv.slice(2);
  const card = await generateAdviceCard({ name, category }, { includeEvidence: process.env.INCLUDE_EVIDENCE === "true" });
  console.log(JSON.stringify(card, null, 2));
}
