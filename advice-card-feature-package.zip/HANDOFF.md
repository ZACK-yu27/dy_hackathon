# 旅程积木避坑建议卡交接文档

## 这个包是什么

这是“避坑建议卡”功能的交接包，只覆盖这一个功能，包含三部分：

1. 已爬取并整理好的杭州旅行数据。
2. 本地 RAG 检索库。
3. 点击模块后生成避坑建议卡的接口、Prompt 和示例。

前端同学不需要理解爬虫和 RAG 的内部实现，只需要调用建议卡接口。

## 包内主要文件

### 1. 交接说明

- `HANDOFF.md`
  - 当前交接文档。
- `UPLOAD_MANIFEST.md`
  - 上传包说明，列出包含/不包含内容。

### 2. 数据文件

- `data/processed/travel_modules.json`
  - 整理后的旅行模块数据。
  - 当前约 160 条，包含景点、餐饮、住宿、避坑、交通等线索。

- `data/rag/travel_rag_index.json`
  - 本地 RAG 检索库。
  - 前端点击模块后，后端会用模块 `name/category` 去这里找相关证据。

- `data/cache/advice_cards.json`
  - 已生成过的建议卡缓存。
  - 第一次生成后会缓存，下次点击同一模块可以直接返回。

- `data/raw/`
  - 原始抓取数据和调试记录。
  - 用于追溯证据来源，不是前端直接使用的数据。

### 3. 爬取和整理脚本

- `tools/safe-crawl/login.js`
  - 打开浏览器让用户手动登录平台。

- `tools/safe-crawl/safe-scrape.js`
  - 安全抓取搜索结果页的公开可见文本。

- `tools/safe-crawl/crawl-details.js`
  - 尝试抓取详情页/笔记正文/评论可见文本。

- `tools/safe-crawl/extract-modules.js`
  - 把原始文本整理成旅行模块。

- `tools/safe-crawl/build-rag.js`
  - 把旅行模块构建成本地 RAG 索引。

- `tools/safe-crawl/query-rag.js`
  - 终端里测试 RAG 检索效果。

### 4. 建议卡功能

- `tools/advice-card/README.md`
  - 建议卡功能使用说明。

- `tools/advice-card/api-contract.md`
  - 前后端接口约定，队友主要看这个。

- `tools/advice-card/prompt-template.md`
  - AI 生成建议卡时使用的 Prompt 模板。

- `tools/advice-card/advice-card.js`
  - RAG 检索、AI 调用、缓存逻辑。

- `tools/advice-card/server.js`
  - 提供 `/api/advice-card` 接口。

- `tools/advice-card/sample-request.json`
  - 前端请求示例。

- `tools/advice-card/sample-response-lingyin.json`
  - 灵隐寺建议卡返回示例。

- `tools/advice-card/.env.example`
  - API Key 配置示例，不包含真实密钥。

## 前端怎么对接

前端点击模块时，请求：

```text
POST /api/advice-card
```

请求体：

```json
{
  "name": "灵隐寺",
  "category": "景点"
}
```

返回：

```json
{
  "name": "灵隐寺",
  "summary": "一句话判断",
  "pitfalls": ["哪里容易踩坑"],
  "executionTips": ["执行提醒"],
  "alternatives": ["替代方案"],
  "confirmBeforeGo": ["需要自行确认"],
  "confidence": "中等偏高",
  "sourceSummary": "来源依据"
}
```

前端展示建议：

- 正文突出展示：`summary`、`pitfalls`、`executionTips`、`alternatives`、`confirmBeforeGo`
- 浅色小字展示：`confidence`、`sourceSummary`

## 建议卡是不是写死的

不是。

固定的是前端卡片结构：

- 一句话判断
- 哪里容易踩坑
- 执行提醒
- 替代方案
- 需要自行确认
- 可信度
- 来源依据

变化的是里面的内容。内容由后端根据 `name/category` 检索 RAG 证据，再调用 AI API 生成。

## 如何运行

安装依赖：

```bash
npm install
```

测试生成建议卡：

```bash
npm run advice:generate -- 灵隐寺 景点
```

启动接口服务：

```bash
npm run advice:server
```

配置 API Key：

```bash
cp tools/advice-card/.env.example tools/advice-card/.env.local
```

然后把 `.env.local` 里的 `DEEPSEEK_API_KEY` 改成真实 key。

注意：`.env.local` 不要上传仓库。

## 已能实现

1. 使用已有本地数据，不需要每次重新爬。
2. 根据模块 `name/category` 检索 RAG 证据。
3. 生成固定格式的建议卡 JSON。
4. 有 API Key 时调用 DeepSeek/OpenAI 风格 API 生成。
5. 没有 API Key 时使用本地兜底逻辑，demo 不会崩。
6. 支持缓存已生成建议卡。

## 还不能完整实现

1. 不能保证稳定抓到完整评论区。
2. 小红书/大众点评如果出现安全限制，不能绕过。
3. 当前 RAG 是本地轻量检索，不是正式向量数据库。
4. 地点别名合并还比较基础。
5. 前端还需要把模块点击事件接到 `/api/advice-card`。
6. 线上部署还需要后端运行环境和 API Key。

## 不要上传的内容

- `data/auth/`
- `node_modules/`
- `tools/advice-card/.env.local`
- `API_keys.md`
- `.DS_Store`

这些已经写进 `.gitignore`。
