# 上传包说明

这个包只用于提交“避坑建议卡 / RAG 数据 / 安全爬取”这一个功能。

## 包含内容

- `package.json`、`package-lock.json`：依赖和脚本命令
- `tools/safe-crawl/`：安全爬取、模块整理、RAG 构建脚本
- `tools/advice-card/`：建议卡接口、Prompt、AI 调用、缓存和示例
- `data/processed/travel_modules.json`：整理后的旅行模块数据
- `data/rag/travel_rag_index.json`：本地 RAG 检索库
- `data/cache/advice_cards.json`：建议卡缓存
- `data/raw/`：原始抓取数据和调试记录

## 不包含内容

- `docs/prd-journey-blocks.md`：完整产品 PRD，不属于本功能交接包
- `已生成图像 1.png`：界面预览图，不属于本功能交接包
- `node_modules/`：依赖包，上传后运行 `npm install` 恢复
- `data/auth/`：浏览器登录态和 Cookies，不能上传
- `tools/advice-card/.env.local`：真实 API Key，不能上传
- `/Users/wuyiqin/Downloads/API_keys.md`：真实 API Key，不能上传
- `.DS_Store`、临时文件

## 已能实现

1. 使用已有 RAG 数据，根据模块 `name/category` 检索避坑证据。
2. 生成固定 JSON 格式的建议卡。
3. 支持 DeepSeek/OpenAI 风格的 API 调用。
4. 没有 API Key 时，有本地兜底建议卡生成逻辑。
5. 前端可以通过 `/api/advice-card` 对接。

## 暂不能完整实现

1. 不能保证稳定抓到完整评论区。
2. 小红书/大众点评如出现安全限制，不能绕过。
3. 当前 RAG 是本地轻量检索，不是正式向量数据库。
4. 前端还需要接入 `/api/advice-card`。
5. 真实部署时需要配置 API Key 和服务运行环境。
